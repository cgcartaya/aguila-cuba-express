"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Loader2, Save } from "lucide-react";

import ProductImageManager from "@/components/admin/products/ProductImageManager";

import {
  getProductById,
  updateProduct,
} from "@/lib/services/products";

import {
  getAdminActiveCategories,
} from "@/lib/services/settings";

import { useAdminAccess } from "@/hooks/useAdminAccess";
import { useStore } from "@/hooks/useStore";

import type { Category } from "@/components/admin/settings/types";

export default function EditProductPage() {
  const router = useRouter();
  const params = useParams();
  const productId = params.id as string;

  const { loading: accessLoading, isSuperAdmin, store: accessStore } =
    useAdminAccess();

  const { store: selectedStore, loading: storeLoading } = useStore();

  const activeStore = useMemo(() => {
    if (isSuperAdmin) {
      return selectedStore || accessStore;
    }

    return accessStore;
  }, [accessStore, isSuperAdmin, selectedStore]);

  const [categories, setCategories] = useState<Category[]>([]);

  const [form, setForm] = useState({
    name: "",
    category: "",
    description: "",
    price: "",
    stock: "",
    tag: "",
    is_active: true,
    minimum_order_exempt: null as boolean | null,
    delivery_included: null as boolean | null,
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadData() {
      if (accessLoading || storeLoading) return;

      if (!activeStore?.id) {
        setError("No se pudo resolver la tienda activa.");
        setLoading(false);
        return;
      }

      const [{ data: product, error }, { data: categoriesData }] =
        await Promise.all([
          getProductById(productId),
          getAdminActiveCategories(activeStore.id),
        ]);

      setCategories(categoriesData || []);

      if (error || !product) {
        setError("No se pudo cargar el producto.");
        setLoading(false);
        return;
      }

      if (product.store_id && product.store_id !== activeStore.id) {
        setError("Este producto no pertenece a la tienda activa.");
        setLoading(false);
        return;
      }

      setForm({
        name: product.name || "",
        category: product.category || "",
        description: product.description || "",
        price: String(product.price || ""),
        stock: String(product.stock || ""),
        tag: product.tag || "",
        is_active: product.is_active ?? true,
        minimum_order_exempt: product.minimum_order_exempt ?? null,
        delivery_included: product.delivery_included ?? null,
      });

      setLoading(false);
    }

    if (productId) {
      loadData();
    }
  }, [productId, accessLoading, storeLoading, activeStore?.id]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleCategoryChange = (
    e: React.ChangeEvent<HTMLSelectElement>
  ) => {
    setForm((prev) => ({
      ...prev,
      category: e.target.value,
    }));
  };

  const handleActiveChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    setForm((prev) => ({
      ...prev,
      is_active: e.target.checked,
    }));
  };

  const handleSubmit = async () => {
    setError("");

    if (!activeStore?.id) {
      setError("No se pudo resolver la tienda activa.");
      return;
    }

    if (!form.name || !form.category || !form.price || !form.stock) {
      setError("Completa nombre, categoría, precio y stock.");
      return;
    }

    const price = Number(form.price);
    const stock = Number(form.stock);

    if (Number.isNaN(price) || price < 0) {
      setError("El precio no es válido.");
      return;
    }

    if (Number.isNaN(stock) || stock < 0) {
      setError("El stock no es válido.");
      return;
    }

    try {
      setSaving(true);

      const { error } = await updateProduct(productId, {
        name: form.name,
        category: form.category,
        description: form.description,
        price,
        stock,
        tag: form.tag,
        is_active: form.is_active,
        minimum_order_exempt: form.minimum_order_exempt,
        delivery_included: form.delivery_included,
      });

      if (error) throw error;

      router.push("/admin/products");
      router.refresh();
    } catch (err) {
      console.error(err);
      setError("No se pudo actualizar el producto.");
    } finally {
      setSaving(false);
    }
  };

  if (loading || accessLoading || storeLoading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-gray-50">
        <div className="flex items-center gap-2 text-gray-600">
          <Loader2 className="animate-spin" size={22} />
          Cargando producto...
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gray-50 p-4 pb-[calc(12rem+env(safe-area-inset-bottom))] md:p-6">
      <div className="mx-auto max-w-4xl">
        <Link
          href="/admin/products"
          className="mb-6 inline-flex items-center gap-2 text-sm font-bold text-gray-600"
        >
          <ArrowLeft size={18} />
          Volver a productos
        </Link>

        <div className="mb-6">
          <h1 className="text-3xl font-black text-gray-900">
            Editar producto
          </h1>

          <p className="mt-2 text-sm font-semibold text-gray-500">
            Actualiza la información, imágenes y estado del producto.
          </p>
        </div>

        <section className="rounded-3xl bg-white p-5 shadow-sm md:p-6">
          <div className="mb-5">
            <h2 className="text-2xl font-black text-slate-900">
              Información del producto
            </h2>
            <p className="mt-1 text-sm font-semibold text-slate-500">
              Estos datos se mostrarán en la tienda pública.
            </p>
          </div>

          <div className="grid gap-5 md:grid-cols-2">
            <Input
              name="name"
              label="Nombre del producto *"
              value={form.name}
              onChange={handleChange}
              placeholder="Ej: Arroz Gallo"
            />

            <CategorySelect
              value={form.category}
              categories={categories}
              onChange={handleCategoryChange}
            />

            <Input
              name="price"
              label="Precio *"
              type="number"
              value={form.price}
              onChange={handleChange}
              placeholder="0.00"
            />

            <Input
              name="stock"
              label="Stock *"
              type="number"
              value={form.stock}
              onChange={handleChange}
              placeholder="0"
            />

            <Input
              name="tag"
              label="Etiqueta"
              value={form.tag}
              onChange={handleChange}
              placeholder="Ej: Oferta, Nuevo"
            />

            <div className="md:col-span-2">
              <label className="mb-2 block text-sm font-black text-gray-700">
                Descripción
              </label>

              <textarea
                name="description"
                value={form.description}
                onChange={handleChange}
                rows={4}
                placeholder="Descripción del producto..."
                className="w-full rounded-2xl border px-4 py-3 outline-none focus:border-black"
              />
            </div>

            <div className="grid gap-4 rounded-2xl border border-slate-200 bg-slate-50 p-4 md:col-span-2 md:grid-cols-2">
              <RuleOverride label="Mínimo de compra" value={form.minimum_order_exempt} onChange={(value) => setForm((prev) => ({ ...prev, minimum_order_exempt: value }))} trueLabel="Exento" falseLabel="Aplicar mínimo" />
              <RuleOverride label="Entrega" value={form.delivery_included} onChange={(value) => setForm((prev) => ({ ...prev, delivery_included: value }))} trueLabel="Incluida" falseLabel="Cobrar delivery" />
              <p className="text-xs font-semibold text-slate-500 md:col-span-2">En “Heredar categoría”, el producto utiliza la configuración definida en su categoría.</p>
            </div>

            <label className="flex items-center gap-3 rounded-2xl border p-4 md:col-span-2">
              <input
                type="checkbox"
                checked={form.is_active}
                onChange={handleActiveChange}
                className="h-5 w-5"
              />

              <div>
                <p className="font-black text-gray-900">
                  Producto activo
                </p>

                <p className="text-sm font-medium text-gray-500">
                  Si está activo, aparecerá en la tienda.
                </p>
              </div>
            </label>
          </div>

          {error && (
            <div className="mt-5 rounded-2xl bg-red-50 px-4 py-3 text-sm font-bold text-red-600">
              {error}
            </div>
          )}

          <div className="mt-6 grid grid-cols-1 gap-3 sm:flex sm:justify-end">
            <Link
              href="/admin/products"
              className="rounded-2xl border px-5 py-3 text-center font-black text-gray-700"
            >
              Cancelar
            </Link>

            <button
              type="button"
              onClick={handleSubmit}
              disabled={saving}
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-black px-5 py-3 font-black text-white disabled:opacity-60"
            >
              {saving ? (
                <>
                  <Loader2 className="animate-spin" size={20} />
                  Guardando...
                </>
              ) : (
                <>
                  <Save size={20} />
                  Guardar cambios
                </>
              )}
            </button>
          </div>
        </section>

        <div className="mt-6">
          <ProductImageManager productId={productId} />
        </div>
      </div>
    </main>
  );
}

function RuleOverride({ label, value, onChange, trueLabel, falseLabel }: { label: string; value: boolean | null; onChange: (value: boolean | null) => void; trueLabel: string; falseLabel: string }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-black text-gray-700">{label}</span>
      <select value={value === null ? "inherit" : value ? "true" : "false"} onChange={(event) => onChange(event.target.value === "inherit" ? null : event.target.value === "true")} className="w-full rounded-2xl border bg-white px-4 py-3 font-bold outline-none focus:border-black">
        <option value="inherit">Heredar categoría</option>
        <option value="true">{trueLabel}</option>
        <option value="false">{falseLabel}</option>
      </select>
    </label>
  );
}

function Input({
  label,
  name,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-black text-gray-700">
        {label}
      </label>

      <input
        name={name}
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="w-full rounded-2xl border px-4 py-3 outline-none focus:border-black"
      />
    </div>
  );
}

function CategorySelect({
  value,
  categories,
  onChange,
}: {
  value: string;
  categories: Category[];
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-black text-gray-700">
        Categoría *
      </label>

      <select
        name="category"
        value={value}
        onChange={onChange}
        disabled={categories.length === 0}
        className="w-full rounded-2xl border bg-white px-4 py-3 outline-none focus:border-black disabled:bg-gray-100"
      >
        <option value="">
          {categories.length === 0
            ? "No hay categorías activas"
            : "Selecciona una categoría"}
        </option>

        {categories.map((category) => (
          <option key={category.id} value={category.name}>
            {category.name}
          </option>
        ))}
      </select>
    </div>
  );
}
