"use client";

import Image from "next/image";
import Link from "next/link";
import { BadgePercent, CheckCircle2, Package } from "lucide-react";

import { useCart } from "@/contexts/CartContext";
import { useStore } from "@/hooks/useStore";
import { trackAnalyticsEvent } from "@/lib/analytics/client";

type ComboItem = {
  id: string;
  quantity: number;
  products?: {
    id: string;
    name: string;
    price: number;
  } | null;
};

export type StoreCombo = {
  id: string;
  name: string;
  description?: string | null;
  image_url?: string | null;
  price: number;
  combo_items?: ComboItem[];
};

type Props = {
  combo: StoreCombo;
  storeSlug?: string;
};

function getSafeImageUrl(url?: string | null) {
  return url?.trim() || "";
}

export default function StoreComboCard({ combo, storeSlug }: Props) {
  const { addComboToCart } = useCart();
  const { store } = useStore();

  const normalPrice =
    combo.combo_items?.reduce((total, item) => {
      return (
        total +
        Number(item.products?.price || 0) * Number(item.quantity || 1)
      );
    }, 0) || 0;

  const comboPrice = Number(combo.price || 0);
  const savings = Math.max(normalPrice - comboPrice, 0);
  const comboImageUrl = getSafeImageUrl(combo.image_url);

  const comboHref = storeSlug
    ? `/tienda/${storeSlug}/combos/${combo.id}`
    : `/tienda/combos/${combo.id}`;

  const visibleItems = combo.combo_items?.slice(0, 2) || [];

  const hiddenItemsCount =
    (combo.combo_items?.length || 0) - visibleItems.length;

  function handleAddCombo() {
    if (store?.id) {
      void trackAnalyticsEvent({
        storeId: store.id,
        eventName: "add_to_cart",
        comboId: combo.id,
        itemName: combo.name,
        quantity: 1,
        value: comboPrice,
      });
    }

    addComboToCart({
      id: combo.id,
      name: combo.name,
      price: combo.price,
      image_url: comboImageUrl,
    });
  }

  return (
    <article className="flex h-full flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white p-3 shadow-sm transition hover:-translate-y-1 hover:shadow-lg">
      <Link
        href={comboHref}
        className="relative mb-3 block h-[145px] w-full overflow-hidden rounded-xl bg-white"
      >
        {savings > 0 && (
          <div className="absolute left-2 top-2 z-10 flex items-center gap-1 rounded-full bg-green-600 px-2 py-1 text-[10px] font-black text-white shadow">
            <BadgePercent size={11} />
            Ahorra ${savings.toFixed(0)}
          </div>
        )}

        {comboImageUrl ? (
          <Image
            src={comboImageUrl}
            alt={combo.name}
            fill
            sizes="(max-width: 640px) 85vw, 360px"
            quality={74}
            className="object-contain p-2 transition duration-300 hover:scale-105"
          />
        ) : (
          <div className="flex h-full items-center justify-center bg-slate-50 text-slate-400">
            <Package size={34} />
          </div>
        )}
      </Link>

      <Link href={comboHref}>
        <h3 className="line-clamp-2 min-h-[42px] text-sm font-black leading-tight text-[#061b3a]">
          {combo.name}
        </h3>
      </Link>

      <div className="mt-3">
        <p className="mb-1 text-[10px] font-black uppercase tracking-wide text-slate-400">
          Incluye
        </p>

        <div className="space-y-1">
          {visibleItems.map((item) => (
            <div
              key={item.id}
              className="flex items-start gap-1 text-[11px] font-semibold text-slate-600"
            >
              <CheckCircle2
                size={12}
                className="mt-[1px] shrink-0 text-green-600"
              />

              <span className="line-clamp-1">
                {item.products?.name || "Producto incluido"}
                {item.quantity > 1 && (
                  <strong className="text-[#061b3a]"> x{item.quantity}</strong>
                )}
              </span>
            </div>
          ))}

          {hiddenItemsCount > 0 && (
            <p className="text-[11px] font-bold text-slate-400">
              +{hiddenItemsCount} productos más
            </p>
          )}
        </div>
      </div>

      <div className="mt-auto pt-4">
        {normalPrice > comboPrice && (
          <p className="text-xs font-semibold text-slate-400 line-through">
            ${normalPrice.toFixed(2)}
          </p>
        )}

        <p className="text-xl font-black text-[#061b3a]">
          ${comboPrice.toFixed(2)}
        </p>
      </div>

      <button
        type="button"
        onClick={handleAddCombo}
        className="mt-3 w-full rounded-xl bg-red-600 py-2.5 text-sm font-black text-white transition hover:bg-red-700"
      >
        Agregar
      </button>
    </article>
  );
}
