"use client";

/* =========================================================
   STORE CONTEXT

   Multiempresa + dominios:
   - Admin: no usa una tienda por defecto.
   - /tienda/[slug]: resuelve por slug.
   - Dominios personalizados: resuelve por domain.
   - Subdominios de PerlaMarketplace:
     dlracing.perlamarketplace.com -> resuelve por subdomain.
   - /tienda sin host/slug resoluble -> no asigna ninguna tienda.
========================================================= */

import { createContext, useContext, useEffect, useState } from "react";
import { usePathname } from "next/navigation";

import type { Store } from "@/lib/saas/store-types";

import {
  getStoreByDomain,
  getStoreById,
  getStoreBySlug,
  getStoreBySubdomain,
} from "@/lib/services/stores";

type StoreContextValue = {
  store: Store | null;
  loading: boolean;
  setCurrentStore: (store: Store) => void;
  clearCurrentStore: () => void;
};

const StoreContext = createContext<StoreContextValue>({
  store: null,
  loading: true,
  setCurrentStore: () => {},
  clearCurrentStore: () => {},
});

const PLATFORM_DOMAIN = "perlamarketplace.com";

const reservedTiendaRoutes = [
  "cart",
  "checkout",
  "producto",
  "productos",
  "combos",
  "productos-destacados",
  "categorias",
];

function normalizeHost(hostname: string) {
  return hostname.replace(/^www\./, "").toLowerCase().trim();
}

function isLocalHost(hostname: string) {
  return (
    hostname === "localhost" ||
    hostname === "127.0.0.1" ||
    hostname.endsWith(".localhost")
  );
}

function getSubdomainFromHost(hostname: string) {
  const host = normalizeHost(hostname);

  if (!host.endsWith(`.${PLATFORM_DOMAIN}`)) return null;

  const subdomain = host.replace(`.${PLATFORM_DOMAIN}`, "").trim();

  if (!subdomain || subdomain === "www") return null;

  return subdomain;
}

export function StoreProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  const [store, setStore] = useState<Store | null>(null);
  const [loading, setLoading] = useState(true);

  function setCurrentStore(newStore: Store) {
    localStorage.setItem("saas-current-store", JSON.stringify(newStore));
    setStore(newStore);
  }

  function clearCurrentStore() {
    localStorage.removeItem("saas-current-store");
    setStore(null);
  }

  useEffect(() => {
    let mounted = true;

    async function finish(currentStore: Store | null) {
      if (!mounted) return;

      setStore(currentStore);
      setLoading(false);
    }

    async function loadStore() {
      setLoading(true);

      const isAdminRoute = pathname.startsWith("/admin");
      const isTiendaRoute = pathname.startsWith("/tienda");

      /* ===============================================
         ADMIN

         Nunca resolvemos una tienda pública por fallback.
         Si hay tienda en localStorage, se usa solo para
         Super Admin. Para Store Owner, los módulos usan
         useAdminAccess().store.
      =============================================== */

      if (isAdminRoute) {
        const savedStore = localStorage.getItem("saas-current-store");

        if (savedStore) {
          try {
            const parsedStore = JSON.parse(savedStore) as Store;
            // Mostramos la copia guardada de una vez (para que no haya
            // parpadeo/carga), pero esa copia es de cuando se eligió la
            // tienda en el switcher — si algo cambió en la base de datos
            // después (ej. platform_fee_enabled), esta copia se queda
            // vieja para siempre porque nada la refresca sola. Por eso
            // revalidamos contra la base de datos en segundo plano y
            // actualizamos tanto el estado como la copia guardada si hay
            // diferencias — así el resto del admin (comisión, ajustes,
            // etc.) nunca vuelve a quedarse viendo datos desactualizados.
            await finish(parsedStore);

            const freshStore = await getStoreById(parsedStore.id);
            if (mounted && freshStore) {
              const changed =
                JSON.stringify(freshStore) !== JSON.stringify(parsedStore);
              if (changed) {
                localStorage.setItem(
                  "saas-current-store",
                  JSON.stringify(freshStore)
                );
                setStore(freshStore);
              }
            }
            return;
          } catch {
            localStorage.removeItem("saas-current-store");
          }
        }

        await finish(null);
        return;
      }

      /* ===============================================
         DOMINIO / SUBDOMINIO

         - aguilacubaexpress.com -> domain en stores.
         - dlracing.perlamarketplace.com -> subdomain en stores.
      =============================================== */

      if (typeof window !== "undefined") {
        const rawHost = window.location.hostname.toLowerCase();
        const cleanHost = normalizeHost(rawHost);

        if (!isLocalHost(cleanHost)) {
          const subdomain = getSubdomainFromHost(cleanHost);

          if (subdomain) {
            const storeBySubdomain = await getStoreBySubdomain(subdomain);

            if (storeBySubdomain) {
              await finish(storeBySubdomain);
              return;
            }
          }

          if (cleanHost !== PLATFORM_DOMAIN) {
            const storeByDomain = await getStoreByDomain(cleanHost);

            if (storeByDomain) {
              await finish(storeByDomain);
              return;
            }
          }
        }
      }

      /* ===============================================
         /tienda/[slug]
      =============================================== */

      if (isTiendaRoute) {
        const parts = pathname.split("/").filter(Boolean);
        const possibleSlug = parts[1];

        if (possibleSlug && !reservedTiendaRoutes.includes(possibleSlug)) {
          const storeBySlug = await getStoreBySlug(possibleSlug);

          if (storeBySlug) {
            await finish(storeBySlug);
            return;
          }
        }
      }

      /*
       * No existe una tienda pública por defecto.
       * Si el dominio/subdominio/slug no identifica una tienda,
       * dejamos el contexto en null para evitar contaminación entre tenants.
       */
      await finish(null);
    }

    loadStore();

    return () => {
      mounted = false;
    };
  }, [pathname]);

  return (
    <StoreContext.Provider
      value={{
        store,
        loading,
        setCurrentStore,
        clearCurrentStore,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  return useContext(StoreContext);
}
