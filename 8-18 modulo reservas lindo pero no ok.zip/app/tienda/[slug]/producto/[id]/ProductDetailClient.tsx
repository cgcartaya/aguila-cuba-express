"use client";

/* =========================================================
   PRODUCT DETAIL PAGE - MULTITIENDA

   Ruta:
   /tienda/[slug]/producto/[id]

   Ejemplo:
   /tienda/dl-racing-cyber/producto/123
========================================================= */

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { ArrowLeft, X } from "lucide-react";

import ProductGallery from "@/components/tienda/product-detail/ProductGallery";
import ProductInfo from "@/components/tienda/product-detail/ProductInfo";
import RelatedProducts from "@/components/tienda/product-detail/RelatedProducts";
import ProductReviews from "@/components/tienda/product-detail/ProductReviews";
import StoreComboCard, { type StoreCombo } from "@/components/tienda/combos/StoreComboCard";

import {
  getStoreProductById,
  getRelatedProducts,
} from "@/lib/services/products";
import { getCombosContainingProduct } from "@/lib/services/combos";

import { useCart } from "@/contexts/CartContext";
import { useStore } from "@/hooks/useStore";
import type { Product } from "@/types/cart";

type ProductImage = {
  id: string;
  image_url: string;
  is_main: boolean;
  position: number | null;
};

type StoreProduct = Product & {
  product_images?: ProductImage[];
};

type ProductDetailClientProps = {
  slug: string;
  id: string;
};

export default function ProductDetailClient({
  slug,
  id,
}: ProductDetailClientProps) {
  const { addToCart } = useCart();
  const { store, loading: storeLoading } = useStore();

  const [product, setProduct] =
    useState<StoreProduct | null>(null);

  const [relatedProducts, setRelatedProducts] =
    useState<Product[]>([]);

  // Combos que incluyen este producto — "cómpralo en combo y ahorra".
  const [relatedCombos, setRelatedCombos] = useState<StoreCombo[]>([]);

  const [selectedImage, setSelectedImage] =
    useState("");

  const [quantity, setQuantity] = useState(1);

  const [isZoomOpen, setIsZoomOpen] =
    useState(false);

  useEffect(() => {
    async function loadProduct() {
      if (storeLoading) return;

      if (!store?.id || store.slug !== slug) {
        setProduct(null);
        setRelatedProducts([]);
        setRelatedCombos([]);
        return;
      }

      const { data, error } =
        await getStoreProductById(id, store.id);

      if (error || !data) {
        console.error(
          "Error cargando producto:",
          error
        );
        return;
      }

      const productData = data as StoreProduct;

      const orderedImages =
        productData.product_images
          ?.slice()
          .sort(
            (a, b) =>
              (a.position ?? 0) -
              (b.position ?? 0)
          ) || [];

      const mainImage =
        orderedImages.find(
          (img) => img.is_main
        ) || orderedImages[0];

      setProduct(productData);

      setSelectedImage(
        mainImage?.image_url ||
          productData.image_url ||
          "/placeholder-product.png"
      );

      if (productData.category) {
        const { data: relatedData } =
          await getRelatedProducts(
            productData.category,
            String(productData.id),
            4,
            store.id
          );

        setRelatedProducts(
          (relatedData as Product[]) || []
        );
      }

      const { data: combosData } = await getCombosContainingProduct(
        String(productData.id),
        store.id,
        4
      );
      setRelatedCombos((combosData as StoreCombo[]) || []);
    }

    loadProduct();
  }, [id, slug, store?.id, store?.slug, storeLoading]);

  if (!product) {
    return (
      <div className="px-4 py-10">
        <p className="text-center text-sm text-slate-500">
          Cargando producto...
        </p>
      </div>
    );
  }

  const productImages =
    product.product_images
      ?.slice()
      .sort(
        (a, b) =>
          (a.position ?? 0) -
          (b.position ?? 0)
      ) || [];

  const imagesToShow =
    productImages.length > 0
      ? productImages
      : [
          {
            id: "fallback",
            image_url:
              product.image_url ||
              "/placeholder-product.png",
            is_main: true,
            position: 0,
          },
        ];

  const handleAddToCart = () => {
    if (Number(product.stock) <= 0)
      return;

    addToCart(
      {
        ...product,
        image_url:
          selectedImage ||
          product.image_url ||
          "/placeholder-product.png",
      },
      quantity
    );
  };

  return (
    <>
      <main className="min-h-screen bg-white pb-24 text-[#061b3a]">
      <div className="mx-auto max-w-6xl px-4 py-5">
        {/* BOTÓN VOLVER */}
        <div className="mb-5">
          <Link
            href={`/tienda/${slug}`}
            className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-black text-[#061b3a] shadow-sm transition hover:-translate-y-0.5 hover:border-red-200 hover:bg-red-50 hover:text-red-600 hover:shadow-md"
          >
            <ArrowLeft size={18} />
            Volver a tienda
          </Link>
        </div>

        {/* INFO PRINCIPAL */}
        <div className="grid gap-8 md:grid-cols-2">
          <ProductGallery
            productName={product.name}
            selectedImage={selectedImage}
            images={imagesToShow}
            onSelectImage={setSelectedImage}
            onOpenZoom={() =>
              setIsZoomOpen(true)
            }
          />

          <ProductInfo
            name={product.name}
            price={Number(product.price)}
            description={
              product.description
            }
            tag={product.tag}
            stock={Number(product.stock)}
            maxQuantityPerOrder={product.max_quantity_per_order}
            priceTiers={product.product_price_tiers}
            quantity={quantity}
            setQuantity={setQuantity}
            onAddToCart={handleAddToCart}
          />
        </div>

        {relatedCombos.length > 0 && (
          <section className="mt-10">
            <h2 className="mb-1 text-2xl font-black text-[#061b3a]">
              Cómpralo en combo y ahorra
            </h2>
            <p className="mb-4 text-sm text-slate-500">
              Este producto también viene incluido en estos combos.
            </p>

            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              {relatedCombos.map((combo) => (
                <StoreComboCard key={combo.id} combo={combo} storeSlug={slug} />
              ))}
            </div>
          </section>
        )}

        <RelatedProducts
          products={relatedProducts}
        />

        {store?.id && (
          <ProductReviews
            productId={String(product.id)}
            storeId={store.id}
            storeSlug={slug}
            ratingAvg={Number(product.rating_avg || 0)}
            ratingCount={Number(product.rating_count || 0)}
          />
        )}
      </div>

      {isZoomOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4">
          <button
            type="button"
            onClick={() =>
              setIsZoomOpen(false)
            }
            className="absolute right-4 top-4 rounded-full bg-white p-3 text-black"
          >
            <X size={22} />
          </button>

          <div className="relative h-[80vh] w-full max-w-4xl">
            <Image
              src={
                selectedImage ||
                "/placeholder-product.png"
              }
              alt={product.name}
              fill
              sizes="100vw"
              className="object-contain"
            />
          </div>
        </div>
      )}
    </main>
    </>
  );
}