"use client";

import { useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useAdminAccess } from "@/hooks/useAdminAccess";
import {
  User,
  MapPin,
  DollarSign,
  Phone,
  Mail,
  CalendarDays,
  ClipboardList,
  Trash2,
  ChevronDown,
  ChevronUp,
  Search,
  PackageCheck,
  Clock,
  Truck,
  RotateCcw,
  Archive,
  AlertTriangle,
  CheckCircle2,
  MessageCircle,
  Share2,
  X,
  Download,
  Loader2,
} from "lucide-react";

import {
  processOrderInventory,
  restoreOrderInventory,
  validateOrderStock,
} from "@/lib/services/inventory";
import {
  cleanWhatsAppPhone,
  openWhatsAppMessage,
  openWhatsAppShare,
} from "@/lib/utils/whatsapp";
import { buildWhatsappOrderMessageFromDbOrder } from "@/lib/utils/checkout";
import { downloadCsv } from "@/lib/utils/csv";

const STATUSES = [
  { value: "Todas", label: "Todas" },
  { value: "pending", label: "Pendiente" },
  { value: "confirmed", label: "Confirmada" },
  { value: "in_transit", label: "En tránsito" },
  { value: "delivered", label: "Entregada" },
  { value: "cancelled", label: "Cancelada" },
];

// "cancelled" se deja en STATUSES para que las órdenes viejas que ya
// tenían ese estado se sigan mostrando bien (filtro "Todas", etiquetas),
// pero se excluye de ORDER_STATUS_OPTIONS para que ya no se pueda elegir
// desde el dropdown — cancelar ahora se hace mandando la orden a la
// papelera (restaura inventario) y, si de verdad no cuenta, Carlos la
// elimina definitivo desde ahí (eso sí resta la comisión pendiente).
const ORDER_STATUS_OPTIONS = STATUSES.filter(
  (status) => status.value !== "Todas" && status.value !== "cancelled"
);

const LEGACY_STATUS_LABELS: Record<string, string> = {
  preparing: "Preparando",
  ready_for_delivery: "Lista para entrega",
};

function getStatusLabel(value: string) {
  return (
    STATUSES.find((status) => status.value === value)?.label ||
    LEGACY_STATUS_LABELS[value] ||
    value
  );
}

function normalizeText(text = "") {
  return text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

function getOrderNumber(order: any) {
  return order.order_number || `#${order.id.slice(0, 8)}`;
}

function getCustomer(order: any) {
  const linked = Array.isArray(order.customers) ? order.customers[0] : order.customers;
  if (linked?.name || linked?.phone) return linked;

  // ARREGLO 2026-08-13: si por lo que sea el pedido nunca quedó
  // enlazado a un cliente (customer_id null) o el cliente vinculado no
  // tiene datos, usamos el nombre/teléfono que se guardó DIRECTO en el
  // pedido al crearlo (order.customer_name / order.customer_phone) —
  // esto ya no depende de que la tabla customers haya funcionado bien
  // en ese momento. Ver create-order/route.ts.
  if (order.customer_name || order.customer_phone) {
    return { name: order.customer_name, phone: order.customer_phone, email: null };
  }

  return linked;
}

function statusClass(status: string) {
  const styles: Record<string, string> = {
    pending: "bg-yellow-100 text-yellow-700",
    confirmed: "bg-blue-100 text-blue-700",
    in_transit: "bg-purple-100 text-purple-700",
    delivered: "bg-green-100 text-green-700",
    cancelled: "bg-red-100 text-red-700",

    // Compatibilidad con estados viejos que puedan existir en la BD.
    preparing: "bg-indigo-100 text-indigo-700",
    ready_for_delivery: "bg-cyan-100 text-cyan-700",
  };

  return styles[status] || "bg-slate-100 text-slate-600";
}

function normalizeOrderItems(order: any) {
  return (order.order_items || []).map((item: any) => ({
    ...item,
    quantity: Number(item.quantity || 0),
    item_type: item.item_type,
    product_id: item.product_id,
    combo_id: item.combo_id,
    product_name: item.product_name,
  }));
}

function getOrderCustomerPhone(order: any) {
  const customer = getCustomer(order);

  return (
    customer?.phone ||
    order.customer_phone ||
    order.phone ||
    order.recipient_phone ||
    order.recipient_phone_alt ||
    ""
  );
}

function buildWhatsAppStatusMessage(order: any, newStatus: string) {
  const customer = getCustomer(order);
  const customerName = customer?.name || order.recipient_name || "cliente";
  const orderNumber = getOrderNumber(order);
  const total = Number(order.total || 0).toFixed(2);

  const statusMessages: Record<string, string> = {
    pending: `Hola ${customerName}, tu pedido ${orderNumber} está pendiente. Total: $${total}. Te avisaremos cuando sea confirmado.`,
    confirmed: `Hola ${customerName}, tu pedido ${orderNumber} fue confirmado. Total: $${total}. Ya estamos trabajando en él.`,
    in_transit: `Hola ${customerName}, tu pedido ${orderNumber} ya está en tránsito. Te avisaremos cuando sea entregado.`,
    delivered: `Hola ${customerName}, tu pedido ${orderNumber} fue marcado como entregado. Gracias por tu compra.`,
    cancelled: `Hola ${customerName}, tu pedido ${orderNumber} fue cancelado. Si tienes alguna duda, escríbenos por aquí.`,
  };

  return (
    statusMessages[newStatus] ||
    `Hola ${customerName}, el estado de tu pedido ${orderNumber} cambió a: ${getStatusLabel(
      newStatus
    )}.`
  );
}

export default function OrdersManager({
  initialOrders,
  initialDeletedOrders = [],
  storeId,
  storeName = "",
  storeSlug = "",
  totalActiveCount,
  totalTrashCount,
  pendingCount,
  confirmedCount,
  transitoCount,
  ventasTotal,
  hasMoreActive = false,
  hasMoreTrash = false,
  loadingMore = false,
  onLoadMoreActive,
  onLoadMoreTrash,
}: {
  initialOrders: any[];
  initialDeletedOrders?: any[];
  storeId: string;
  storeName?: string;
  storeSlug?: string;
  totalActiveCount?: number;
  totalTrashCount?: number;
  pendingCount?: number;
  confirmedCount?: number;
  transitoCount?: number;
  ventasTotal?: number;
  hasMoreActive?: boolean;
  hasMoreTrash?: boolean;
  loadingMore?: boolean;
  onLoadMoreActive?: () => void;
  onLoadMoreTrash?: () => void;
}) {
  const { isSuperAdmin } = useAdminAccess();

  const [orders, setOrders] = useState(initialOrders);
  const [deletedOrders, setDeletedOrders] = useState(initialDeletedOrders);
  const [view, setView] = useState<"active" | "trash">("active");
  const [filter, setFilter] = useState("Todas");
  const [search, setSearch] = useState("");
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [expandedOrders, setExpandedOrders] = useState<Record<string, boolean>>(
    {}
  );
  const [whatsAppPrompt, setWhatsAppPrompt] = useState<{
    order: any;
    status: string;
    phone: string;
    message: string;
  } | null>(null);
  const [shareOrderPrompt, setShareOrderPrompt] = useState<{
    order: any;
    message: string;
  } | null>(null);

  const normalizedStoreIdentity = `${storeName} ${storeSlug}`
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");

  const prefersWhatsAppBusiness =
    normalizedStoreIdentity.includes("aguila") ||
    normalizedStoreIdentity.includes("cuba express");

  const currentOrders = view === "active" ? orders : deletedOrders;

  function toggleItems(orderId: string) {
    setExpandedOrders((prev) => ({
      ...prev,
      [orderId]: !prev[orderId],
    }));
  }

  function assertOrderBelongsToActiveStore(order: any) {
    if (!storeId) {
      throw new Error("No se pudo resolver la tienda activa.");
    }

    if (!order?.store_id || order.store_id !== storeId) {
      throw new Error(
        "Esta orden no pertenece a la tienda activa. La operación fue bloqueada."
      );
    }
  }

  const stats = useMemo(() => {
    const totalSales =
      ventasTotal != null
        ? ventasTotal
        : orders.reduce((sum, order) => sum + Number(order.total || 0), 0);

    return {
      total: totalActiveCount ?? orders.length,
      trash: totalTrashCount ?? deletedOrders.length,
      pendientes:
        pendingCount ?? orders.filter((o) => o.status === "pending").length,
      confirmadas:
        confirmedCount ??
        orders.filter((o) => o.status === "confirmed").length,
      transito:
        transitoCount ??
        orders.filter((o) => o.status === "in_transit").length,
      ventas: totalSales,
    };
  }, [
    orders,
    deletedOrders,
    totalActiveCount,
    totalTrashCount,
    pendingCount,
    confirmedCount,
    transitoCount,
    ventasTotal,
  ]);

  const filteredOrders = useMemo(() => {
    const query = normalizeText(search);

    return currentOrders.filter((order) => {
      const customer = getCustomer(order);

      const matchesStatus =
        filter === "Todas" ? true : order.status === filter;

      const searchableText = normalizeText(`
        ${order.order_number || ""}
        ${order.id || ""}
        ${customer?.name || ""}
        ${customer?.email || ""}
        ${customer?.phone || ""}
        ${order.recipient_name || ""}
        ${order.recipient_phone || ""}
        ${order.address || ""}
        ${order.exact_address || ""}
        ${order.municipality || ""}
        ${order.zone_name || ""}
      `);

      const matchesSearch = !query
        ? true
        : query
            .split(" ")
            .filter(Boolean)
            .every((word) => searchableText.includes(word));

      return matchesStatus && matchesSearch;
    });
  }, [currentOrders, filter, search]);

  async function updateStatus(order: any, status: string) {
    const previousStatus = order.status;

    if (previousStatus === status) return;

    try {
      setActionLoadingId(order.id);
      assertOrderBelongsToActiveStore(order);

      const { data: updated, error } = await supabase
        .from("orders")
        .update({ status })
        .eq("id", order.id)
        .eq("store_id", storeId)
        .is("deleted_at", null)
        .select("id")
        .maybeSingle();

      if (error) throw error;
      if (!updated) {
        throw new Error(
          "No se pudo actualizar la orden dentro de la tienda activa."
        );
      }

      setOrders((prev) =>
        prev.map((item) =>
          item.id === order.id ? { ...item, status } : item
        )
      );

      const updatedOrder = { ...order, status };
      const phone = cleanWhatsAppPhone(getOrderCustomerPhone(updatedOrder));

      if (!phone) {
        alert(
          "El estado fue actualizado, pero esta orden no tiene teléfono del cliente para generar el WhatsApp."
        );
        return;
      }

      setWhatsAppPrompt({
        order: updatedOrder,
        status,
        phone,
        message: buildWhatsAppStatusMessage(updatedOrder, status),
      });
    } catch (error: any) {
      console.error("ERROR ACTUALIZANDO ESTADO:", error);
      alert(error?.message || "Error actualizando estado.");
    } finally {
      setActionLoadingId(null);
    }
  }

  async function sendOrderToTrash(order: any) {
    const ok = confirm(
      "¿Seguro que deseas enviar esta orden a la papelera?\n\nEl inventario de los productos de esta orden será restaurado automáticamente."
    );

    if (!ok) return;

    try {
      setActionLoadingId(order.id);
      assertOrderBelongsToActiveStore(order);

      // Si el pago con tarjeta venció solo (checkout.session.expired), el
      // webhook ya devolvió el stock automáticamente — no volver a
      // hacerlo aquí, o se duplicaría.
      if (!order.stock_restored) {
        const orderItems = normalizeOrderItems(order);
        await restoreOrderInventory(orderItems, storeId);
      }

      const deletedAt = new Date().toISOString();

      const { data: updated, error } = await supabase
        .from("orders")
        .update({ deleted_at: deletedAt, stock_restored: true })
        .eq("id", order.id)
        .eq("store_id", storeId)
        .is("deleted_at", null)
        .select("id")
        .maybeSingle();

      if (error) throw error;
      if (!updated) {
        throw new Error(
          "No se pudo enviar la orden a la papelera: no tienes permiso sobre esta tienda, o la orden ya no existe."
        );
      }

      const deletedOrder = {
        ...order,
        deleted_at: deletedAt,
      };

      setOrders((prev) => prev.filter((item) => item.id !== order.id));
      setDeletedOrders((prev) => [deletedOrder, ...prev]);
    } catch (error: any) {
      console.error("ERROR ENVIANDO ORDEN A PAPELERA:", error);
      alert(error?.message || "No se pudo enviar la orden a la papelera.");
    } finally {
      setActionLoadingId(null);
    }
  }

  async function restoreOrderFromTrash(order: any) {
    const ok = confirm(
      "¿Quieres restaurar esta orden?\n\nEl inventario volverá a descontarse. Si no hay stock suficiente, la restauración se cancelará."
    );

    if (!ok) return;

    try {
      setActionLoadingId(order.id);
      assertOrderBelongsToActiveStore(order);

      const orderItems = normalizeOrderItems(order);

      await validateOrderStock(orderItems, storeId);
      await processOrderInventory(orderItems, storeId);

      const { data: updated, error } = await supabase
        .from("orders")
        .update({ deleted_at: null, stock_restored: false })
        .eq("id", order.id)
        .eq("store_id", storeId)
        .not("deleted_at", "is", null)
        .select("id")
        .maybeSingle();

      if (error) throw error;
      if (!updated) {
        throw new Error(
          "No se pudo restaurar la orden: no tienes permiso sobre esta tienda, o la orden ya no existe."
        );
      }

      const restoredOrder = {
        ...order,
        deleted_at: null,
      };

      setDeletedOrders((prev) => prev.filter((item) => item.id !== order.id));
      setOrders((prev) => [restoredOrder, ...prev]);
      setView("active");
    } catch (error: any) {
      console.error("ERROR RESTAURANDO ORDEN:", error);
      alert(error?.message || "No se pudo restaurar la orden.");
    } finally {
      setActionLoadingId(null);
    }
  }

  async function deleteOrderPermanently(order: any) {
    if (!isSuperAdmin) {
      alert(
        "Solo el Super Admin puede eliminar una orden definitivamente de la papelera."
      );
      return;
    }

    const ok = confirm(
      "Esta acción eliminará la orden definitivamente de la base de datos.\n\nNo se tocará inventario porque ya fue restaurado al enviarla a papelera.\n\nOJO: mientras una orden esté en la papelera (sin eliminar definitivo), su comisión de plataforma SIGUE contando como pendiente. Al eliminarla definitivo, esa comisión deja de contarse.\n\n¿Deseas continuar?"
    );

    if (!ok) return;

    try {
      setActionLoadingId(order.id);
      assertOrderBelongsToActiveStore(order);

      // order_items no tiene store_id, así que primero demostramos que la
      // orden pertenece a la tienda activa y está realmente en papelera.
      const { data: ownedOrder, error: ownershipError } = await supabase
        .from("orders")
        .select("id")
        .eq("id", order.id)
        .eq("store_id", storeId)
        .not("deleted_at", "is", null)
        .maybeSingle();

      if (ownershipError) throw ownershipError;
      if (!ownedOrder) {
        throw new Error(
          "La orden no pertenece a la tienda activa o ya no está en papelera."
        );
      }

      const { error: itemsError } = await supabase
        .from("order_items")
        .delete()
        .eq("order_id", ownedOrder.id);

      if (itemsError) throw itemsError;

      const { data: deletedOrder, error: orderError } = await supabase
        .from("orders")
        .delete()
        .eq("id", ownedOrder.id)
        .eq("store_id", storeId)
        .not("deleted_at", "is", null)
        .select("id")
        .maybeSingle();

      if (orderError) throw orderError;
      if (!deletedOrder) {
        throw new Error(
          "No se pudo eliminar la orden: no tienes permiso sobre esta tienda, o la orden ya no existe."
        );
      }

      setDeletedOrders((prev) => prev.filter((item) => item.id !== order.id));
    } catch (error: any) {
      console.error("ERROR ELIMINANDO ORDEN DEFINITIVAMENTE:", error);
      alert(error?.message || "No se pudo eliminar definitivamente la orden.");
    } finally {
      setActionLoadingId(null);
    }
  }

  function shareOrderByWhatsapp(order: any) {
    const orderUrl = `${window.location.origin}/pedido/${getOrderNumber(order).replace("#", "")}`;

    const message = buildWhatsappOrderMessageFromDbOrder({
      order,
      customer: getCustomer(order),
      orderItems: normalizeOrderItems(order),
      orderUrl,
    });

    setShareOrderPrompt({ order, message });
  }

  function handleExportCsv() {
    downloadCsv(
      `ordenes-${view}-${new Date().toISOString().slice(0, 10)}`,
      [
        "Orden",
        "Fecha",
        "Cliente",
        "Teléfono",
        "Estado",
        "Subtotal",
        "Envío",
        "Comisión plataforma",
        "Total",
      ],
      filteredOrders.map((order) => {
        const customer = getCustomer(order);

        return [
          getOrderNumber(order),
          new Date(order.created_at).toLocaleDateString("es"),
          customer?.name || "",
          customer?.phone || order.recipient_phone || "",
          getStatusLabel(order.status),
          Number(order.subtotal || 0).toFixed(2),
          Number(order.delivery_fee || 0).toFixed(2),
          Number(order.platform_fee_amount || 0).toFixed(2),
          Number(order.total || 0).toFixed(2),
        ];
      })
    );
  }

  return (
    <>
      <section className="mb-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-6">
        <StatCard
          label="Órdenes activas"
          value={stats.total}
          icon={PackageCheck}
          color="bg-slate-900 text-white"
        />

        <StatCard
          label="Papelera"
          value={stats.trash}
          icon={Archive}
          color="bg-red-100 text-red-700"
        />

        <StatCard
          label="Pendientes"
          value={stats.pendientes}
          icon={Clock}
          color="bg-yellow-100 text-yellow-700"
        />

        <StatCard
          label="Confirmadas"
          value={stats.confirmadas}
          icon={CheckCircle2}
          color="bg-blue-100 text-blue-700"
        />

        <StatCard
          label="En tránsito"
          value={stats.transito}
          icon={Truck}
          color="bg-purple-100 text-purple-700"
        />

        <StatCard
          label="Ventas activas"
          value={`$${stats.ventas.toFixed(2)}`}
          icon={DollarSign}
          color="bg-green-100 text-green-700"
        />
      </section>

      <section className="mb-5 flex flex-wrap gap-2 rounded-3xl bg-white p-3 shadow-sm">
        <button
          type="button"
          onClick={() => setView("active")}
          className={`rounded-2xl px-4 py-3 text-sm font-black transition ${
            view === "active"
              ? "bg-[#061b3a] text-white"
              : "bg-slate-50 text-slate-600 hover:bg-slate-100"
          }`}
        >
          Órdenes activas ({totalActiveCount ?? orders.length})
        </button>

        <button
          type="button"
          onClick={() => setView("trash")}
          className={`rounded-2xl px-4 py-3 text-sm font-black transition ${
            view === "trash"
              ? "bg-red-600 text-white"
              : "bg-red-50 text-red-600 hover:bg-red-100"
          }`}
        >
          Papelera ({totalTrashCount ?? deletedOrders.length})
        </button>
      </section>

      {view === "trash" && (
        <div className="mb-5 flex items-start gap-3 rounded-2xl bg-amber-50 p-4 text-sm font-bold text-amber-700">
          <AlertTriangle className="mt-0.5 shrink-0" size={20} />
          <p>
            Las órdenes en papelera no cuentan en ventas ni estadísticas. Al
            restaurarlas, el inventario se volverá a descontar automáticamente.
          </p>
        </div>
      )}

      <section className="mb-5 rounded-3xl bg-white p-4 shadow-sm">
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="flex flex-1 items-center gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
            <Search size={20} className="text-slate-400" />

            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar por orden, cliente, teléfono, email o dirección..."
              className="w-full bg-transparent text-sm font-semibold text-slate-700 outline-none placeholder:text-slate-400"
            />
          </div>

          <button
            type="button"
            onClick={handleExportCsv}
            disabled={filteredOrders.length === 0}
            className="flex items-center justify-center gap-2 rounded-2xl border px-4 py-3 text-sm font-bold text-slate-600 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
            title="Exportar las órdenes visibles a CSV"
          >
            <Download size={18} />
            Exportar CSV
          </button>
        </div>

        {(view === "active" ? hasMoreActive : hasMoreTrash) && (
          <p className="mt-3 text-xs font-semibold text-amber-700">
            La búsqueda y el filtro solo revisan las órdenes ya cargadas.
            Usa "Cargar más" al final de la lista para traer órdenes más
            antiguas.
          </p>
        )}
      </section>

      <div className="mb-6 flex flex-wrap gap-2">
        {STATUSES.map((status) => (
          <button
            key={status.value}
            onClick={() => setFilter(status.value)}
            className={`rounded-full px-4 py-2 text-sm font-black transition ${
              filter === status.value
                ? "bg-[#061b3a] text-white"
                : "bg-white text-slate-600 shadow-sm"
            }`}
          >
            {status.label}
          </button>
        ))}
      </div>

      {filteredOrders.length === 0 ? (
        <div className="rounded-3xl bg-white p-10 text-center shadow-sm">
          <ClipboardList className="mx-auto mb-3 text-slate-400" size={42} />

          <h2 className="text-xl font-black text-[#061b3a]">
            {view === "trash"
              ? "No hay órdenes en papelera"
              : "No hay órdenes para mostrar"}
          </h2>

          <p className="mt-2 text-sm font-semibold text-slate-500">
            Cambia el filtro o prueba otra búsqueda.
          </p>
        </div>
      ) : (
        <div className="space-y-5">
          {filteredOrders.map((order) => {
            const customer = getCustomer(order);
            const orderNumber = getOrderNumber(order);
            const isActionLoading = actionLoadingId === order.id;

            return (
              <article
                key={order.id}
                className="overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-100"
              >
                <div className="border-b border-slate-100 p-5">
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                    <div>
                      <p className="text-xs font-black uppercase text-slate-400">
                        Orden
                      </p>

                      <h2 className="mt-1 text-xl font-black text-[#061b3a]">
                        {orderNumber}
                      </h2>

                      <p className="mt-1 text-xs font-semibold text-slate-400">
                        ID interno: {order.id.slice(0, 8)}
                      </p>

                      {view === "trash" && order.deleted_at && (
                        <p className="mt-2 text-xs font-bold text-red-500">
                          En papelera desde:{" "}
                          {new Date(order.deleted_at).toLocaleString("es-US")}
                        </p>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      <span
                        className={`rounded-full px-3 py-1 text-xs font-black ${statusClass(
                          order.status
                        )}`}
                      >
                        {getStatusLabel(order.status)}
                      </span>

                      {order.payment_method === "card" ? (
                        order.payment_status === "paid" ? (
                          <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-black text-emerald-700">
                            💳 Tarjeta pagada
                          </span>
                        ) : order.payment_status === "expired" ? (
                          <span className="rounded-full bg-red-100 px-3 py-1 text-xs font-black text-red-700">
                            💳 Pago no completado
                          </span>
                        ) : (
                          <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-black text-amber-700">
                            💳 Tarjeta — esperando pago
                          </span>
                        )
                      ) : (
                        <span className="rounded-full bg-purple-100 px-3 py-1 text-xs font-black text-purple-700">
                          🟣 Zelle
                        </span>
                      )}

                      {view === "active" && (
                        <select
                          value={order.status}
                          onChange={(e) => updateStatus(order, e.target.value)}
                          disabled={isActionLoading}
                          className="rounded-xl border border-slate-300 bg-white p-2 text-sm font-bold text-slate-700 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          {!ORDER_STATUS_OPTIONS.some(
                            (status) => status.value === order.status
                          ) && (
                            <option value={order.status}>
                              {getStatusLabel(order.status)}
                            </option>
                          )}

                          {ORDER_STATUS_OPTIONS.map((status) => (
                            <option key={status.value} value={status.value}>
                              {status.label}
                            </option>
                          ))}
                        </select>
                      )}

                      <span className="rounded-full bg-green-100 px-3 py-1 text-xs font-black text-green-700">
                        ${Number(order.total || 0).toFixed(2)}
                      </span>

                      <button
                        type="button"
                        onClick={() => shareOrderByWhatsapp(order)}
                        className="rounded-xl bg-emerald-50 p-3 text-emerald-600 transition hover:bg-emerald-100"
                        aria-label="Compartir orden por WhatsApp"
                        title="Compartir esta orden por WhatsApp (para repartidores)"
                      >
                        <Share2 size={18} />
                      </button>

                      {view === "active" ? (
                        <button
                          type="button"
                          onClick={() => sendOrderToTrash(order)}
                          disabled={isActionLoading}
                          className="rounded-xl bg-red-50 p-3 text-red-600 transition hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-50"
                          aria-label="Enviar orden a la papelera"
                          title="Enviar a papelera y restaurar stock"
                        >
                          <Trash2 size={18} />
                        </button>
                      ) : (
                        <>
                          <button
                            type="button"
                            onClick={() => restoreOrderFromTrash(order)}
                            disabled={isActionLoading}
                            className="inline-flex items-center gap-2 rounded-xl bg-green-50 px-3 py-3 text-xs font-black text-green-700 transition hover:bg-green-100 disabled:cursor-not-allowed disabled:opacity-50"
                            title="Restaurar orden y descontar stock"
                          >
                            <RotateCcw size={16} />
                            Restaurar
                          </button>

                          {isSuperAdmin && (
                            <button
                              type="button"
                              onClick={() => deleteOrderPermanently(order)}
                              disabled={isActionLoading}
                              className="inline-flex items-center gap-2 rounded-xl bg-red-50 px-3 py-3 text-xs font-black text-red-700 transition hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-50"
                              title="Eliminar definitivamente"
                            >
                              <Trash2 size={16} />
                              Eliminar definitivo
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid gap-4 p-5 lg:grid-cols-3">
                  <section className="rounded-2xl bg-slate-50 p-4">
                    <div className="mb-3 flex items-center gap-2 font-black">
                      <User size={18} />
                      Cliente
                    </div>

                    <p className="font-black">
                      {customer?.name || "Cliente sin nombre"}
                    </p>

                    {customer?.email && (
                      <p className="mt-2 flex items-center gap-2 text-sm font-semibold text-slate-500">
                        <Mail size={15} />
                        {customer.email}
                      </p>
                    )}

                    {customer?.phone && (
                      <p className="mt-2 flex items-center gap-2 text-sm font-semibold text-slate-500">
                        <Phone size={15} />
                        {customer.phone}
                      </p>
                    )}
                  </section>

                  <section className="rounded-2xl bg-slate-50 p-4">
                    <div className="mb-3 flex items-center gap-2 font-black">
                      <MapPin size={18} />
                      Entrega
                    </div>

                    <p className="font-semibold">
                      {order.exact_address || order.address || "Sin dirección"}
                    </p>

                    <p className="mt-1 text-sm font-semibold text-slate-500">
                      {order.municipality || order.state || ""}{" "}
                      {order.zone_name || order.zip_code || ""}
                    </p>

                    <p className="text-sm font-semibold text-slate-500">
                      {order.country || "Cuba"}
                    </p>

                    {(order.recipient_name || order.recipient_phone) && (
                      <div className="mt-3 rounded-xl bg-white p-3 text-sm font-semibold text-slate-500">
                        {order.recipient_name && (
                          <p>Recibe: {order.recipient_name}</p>
                        )}

                        {order.recipient_phone && (
                          <p>Tel: {order.recipient_phone}</p>
                        )}
                      </div>
                    )}
                  </section>

                  <section className="rounded-2xl bg-slate-50 p-4">
                    <div className="mb-3 flex items-center gap-2 font-black">
                      <DollarSign size={18} />
                      Resumen
                    </div>

                    <p className="flex items-center gap-2 text-sm font-semibold text-slate-500">
                      <CalendarDays size={15} />
                      {new Date(order.created_at).toLocaleString("es-US", {
                        dateStyle: "short",
                        timeStyle: "short",
                      })}
                    </p>

                    <div className="mt-3 space-y-1 text-sm font-semibold text-slate-500">
                      <div className="flex items-center justify-between">
                        <span>Productos</span>
                        <span>${Number(order.subtotal || 0).toFixed(2)}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Envío</span>
                        <span>${Number(order.delivery_fee || 0).toFixed(2)}</span>
                      </div>
                      {Number(order.discount_amount || 0) > 0 && (
                        <div className="flex items-center justify-between text-emerald-700">
                          <span>Descuento</span>
                          <span>-${Number(order.discount_amount).toFixed(2)}</span>
                        </div>
                      )}
                    </div>

                    <p className="mt-2 text-2xl font-black">
                      ${Number(order.total || 0).toFixed(2)}
                    </p>

                    {Number(order.platform_fee_amount || 0) > 0 && (
                      <p className="mt-1 text-xs font-semibold text-emerald-700">
                        Incluye ${Number(order.platform_fee_amount).toFixed(2)} de comisión de plataforma
                      </p>
                    )}

                    <p className="mt-1 text-xs font-bold text-slate-500">
                      Pago: {
                        order.payment_status === "paid"
                          ? "Pagado"
                          : order.payment_status === "expired"
                            ? "No completado (venció sin pagar)"
                            : "Pendiente"
                      }
                      {order.payment_method && (
                        <> · {order.payment_method === "card" ? "Tarjeta" : "WhatsApp"}</>
                      )}
                    </p>
                  </section>
                </div>

                <div className="px-5 pb-5">
                  <section className="overflow-hidden rounded-2xl bg-slate-50">
                    <button
                      type="button"
                      onClick={() => toggleItems(order.id)}
                      className="flex w-full items-center justify-between p-4 text-left transition hover:bg-slate-100"
                    >
                      <div className="flex items-center gap-3">
                        <ClipboardList size={20} />

                        <div>
                          <h3 className="font-black">
                            Items del pedido ({order.order_items?.length || 0})
                          </h3>

                          <p className="text-sm text-slate-500">
                            Toca para ver los productos
                          </p>
                        </div>
                      </div>

                      {expandedOrders[order.id] ? (
                        <ChevronUp size={22} />
                      ) : (
                        <ChevronDown size={22} />
                      )}
                    </button>

                    {expandedOrders[order.id] && (
                      <div className="space-y-3 border-t border-slate-200 p-4">
                        {order.order_items?.map((item: any) => (
                          <div
                            key={item.id}
                            className="rounded-2xl bg-white p-4 shadow-sm"
                          >
                            <div className="flex items-start justify-between gap-4">
                              <div>
                                <span className="mb-2 inline-block rounded-full bg-blue-100 px-2 py-1 text-xs font-bold text-blue-700">
                                  {item.item_type === "combo"
                                    ? "Combo"
                                    : "Producto"}
                                </span>

                                <p className="font-black">{item.product_name}</p>

                                <p className="mt-1 text-sm text-slate-500">
                                  {item.quantity} × $
                                  {Number(item.price || 0).toFixed(2)}
                                </p>
                              </div>

                              <p className="font-black text-green-600">
                                ${Number(item.subtotal || 0).toFixed(2)}
                              </p>
                            </div>
                          </div>
                        ))}

                        <div className="space-y-1.5 border-t pt-4 text-sm font-semibold text-slate-600">
                          <div className="flex items-center justify-between">
                            <span>Productos</span>
                            <span>${Number(order.subtotal || 0).toFixed(2)}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span>Envío</span>
                            <span>${Number(order.delivery_fee || 0).toFixed(2)}</span>
                          </div>
                          {Number(order.discount_amount || 0) > 0 && (
                            <div className="flex items-center justify-between text-emerald-700">
                              <span>Descuento</span>
                              <span>-${Number(order.discount_amount).toFixed(2)}</span>
                            </div>
                          )}
                          {Number(order.platform_fee_amount || 0) > 0 && (
                            <p className="pt-1 text-xs font-semibold text-emerald-700">
                              Incluye ${Number(order.platform_fee_amount).toFixed(2)} de comisión de plataforma (ya está dentro del total)
                            </p>
                          )}
                          <div className="flex items-center justify-between border-t pt-2 text-lg font-black text-[#061b3a]">
                            <span>Total</span>
                            <span className="text-green-600">
                              ${Number(order.total || 0).toFixed(2)}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </section>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {(view === "active" ? hasMoreActive : hasMoreTrash) &&
        filteredOrders.length > 0 && (
          <div className="mt-5 flex justify-center">
            <button
              type="button"
              onClick={() =>
                view === "active" ? onLoadMoreActive?.() : onLoadMoreTrash?.()
              }
              disabled={loadingMore}
              className="inline-flex items-center gap-2 rounded-2xl border bg-white px-6 py-3 text-sm font-black text-slate-700 shadow-sm transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loadingMore ? (
                <>
                  <Loader2 size={18} className="animate-spin" />
                  Cargando...
                </>
              ) : (
                "Cargar más órdenes"
              )}
            </button>
          </div>
        )}


      {whatsAppPrompt && (
        <div className="fixed inset-0 z-[100] flex items-end justify-center bg-slate-950/55 p-4 sm:items-center">
          <div className="w-full max-w-md rounded-3xl bg-white p-5 shadow-2xl">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-black uppercase tracking-wide text-green-600">
                  Estado actualizado
                </p>
                <h2 className="mt-1 text-xl font-black text-[#061b3a]">
                  Enviar aviso por WhatsApp
                </h2>
                <p className="mt-2 text-sm font-semibold text-slate-500">
                  Orden {getOrderNumber(whatsAppPrompt.order)} · {whatsAppPrompt.phone}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setWhatsAppPrompt(null)}
                className="rounded-xl bg-slate-100 p-2 text-slate-500 hover:bg-slate-200"
                aria-label="Cerrar"
              >
                <X size={20} />
              </button>
            </div>

            <div className="mt-5 space-y-3">
              {prefersWhatsAppBusiness && (
                <button
                  type="button"
                  onClick={() => {
                    openWhatsAppMessage({
                      app: "business",
                      phone: whatsAppPrompt.phone,
                      message: whatsAppPrompt.message,
                    });
                    setWhatsAppPrompt(null);
                  }}
                  className="flex w-full items-center justify-center gap-3 rounded-2xl bg-green-600 px-4 py-4 text-sm font-black text-white transition hover:bg-green-700"
                >
                  <MessageCircle size={21} />
                  Abrir WhatsApp Business
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  openWhatsAppMessage({
                    app: "personal",
                    phone: whatsAppPrompt.phone,
                    message: whatsAppPrompt.message,
                  });
                  setWhatsAppPrompt(null);
                }}
                className={`flex w-full items-center justify-center gap-3 rounded-2xl px-4 py-4 text-sm font-black transition ${
                  prefersWhatsAppBusiness
                    ? "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    : "bg-green-600 text-white hover:bg-green-700"
                }`}
              >
                <MessageCircle size={21} />
                Abrir WhatsApp normal
              </button>

              <button
                type="button"
                onClick={() => setWhatsAppPrompt(null)}
                className="w-full rounded-2xl px-4 py-3 text-sm font-black text-slate-500 hover:bg-slate-50"
              >
                No enviar ahora
              </button>
            </div>
          </div>
        </div>
      )}

      {shareOrderPrompt && (
        <div className="fixed inset-0 z-[100] flex items-end justify-center bg-slate-950/55 p-4 sm:items-center">
          <div className="w-full max-w-md rounded-3xl bg-white p-5 shadow-2xl">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-black uppercase tracking-wide text-emerald-600">
                  Compartir orden
                </p>
                <h2 className="mt-1 text-xl font-black text-[#061b3a]">
                  Enviar a un repartidor
                </h2>
                <p className="mt-2 text-sm font-semibold text-slate-500">
                  Orden {getOrderNumber(shareOrderPrompt.order)} — elige el chat o grupo al que se manda.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShareOrderPrompt(null)}
                className="rounded-xl bg-slate-100 p-2 text-slate-500 hover:bg-slate-200"
                aria-label="Cerrar"
              >
                <X size={20} />
              </button>
            </div>

            <div className="mt-5 space-y-3">
              {prefersWhatsAppBusiness && (
                <button
                  type="button"
                  onClick={() => {
                    openWhatsAppShare({ app: "business", message: shareOrderPrompt.message });
                    setShareOrderPrompt(null);
                  }}
                  className="flex w-full items-center justify-center gap-3 rounded-2xl bg-green-600 px-4 py-4 text-sm font-black text-white transition hover:bg-green-700"
                >
                  <Share2 size={21} />
                  Abrir WhatsApp Business
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  openWhatsAppShare({ app: "personal", message: shareOrderPrompt.message });
                  setShareOrderPrompt(null);
                }}
                className={`flex w-full items-center justify-center gap-3 rounded-2xl px-4 py-4 text-sm font-black transition ${
                  prefersWhatsAppBusiness
                    ? "bg-slate-100 text-slate-700 hover:bg-slate-200"
                    : "bg-green-600 text-white hover:bg-green-700"
                }`}
              >
                <Share2 size={21} />
                Abrir WhatsApp normal
              </button>

              <button
                type="button"
                onClick={() => setShareOrderPrompt(null)}
                className="w-full rounded-2xl px-4 py-3 text-sm font-black text-slate-500 hover:bg-slate-50"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function StatCard({
  label,
  value,
  icon: Icon,
  color,
}: {
  label: string;
  value: string | number;
  icon: any;
  color: string;
}) {
  return (
    <div className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-100">
      <div
        className={`mb-4 flex h-12 w-12 items-center justify-center rounded-2xl ${color}`}
      >
        <Icon size={24} />
      </div>

      <p className="text-sm font-bold text-slate-500">{label}</p>
      <p className="mt-1 text-2xl font-black text-[#061b3a]">{value}</p>
    </div>
  );
}
