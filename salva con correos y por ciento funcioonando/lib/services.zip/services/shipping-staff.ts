"use client";

import { supabase } from "@/lib/supabase";
import type { StaffShipment, StaffUser, StaffUserInput } from "@/lib/shipping/staff-types";

const STAFF_PHOTOS_BUCKET = "staff-photos";

function normalize(value?: string) {
  const cleaned = value?.trim();
  return cleaned || null;
}

function extension(file: File) {
  const byName = file.name.split(".").pop()?.toLowerCase();
  if (byName && ["jpg", "jpeg", "png", "webp"].includes(byName)) return byName === "jpeg" ? "jpg" : byName;
  if (file.type === "image/png") return "png";
  if (file.type === "image/webp") return "webp";
  return "jpg";
}

export async function getShippingStaff(storeId: string) {
  const { data, error } = await supabase
    .from("staff_users")
    .select("*")
    .eq("store_id", storeId)
    .order("first_name", { ascending: true })
    .order("last_name", { ascending: true });

  return { data: (data || []) as StaffUser[], error };
}

export async function uploadStaffPhoto(storeId: string, file: File) {
  const path = `${storeId}/${crypto.randomUUID()}.${extension(file)}`;
  const { error } = await supabase.storage
    .from(STAFF_PHOTOS_BUCKET)
    .upload(path, file, { cacheControl: "3600", upsert: false, contentType: file.type || "image/jpeg" });

  if (error) return { url: null, path: null, error };

  const { data } = supabase.storage.from(STAFF_PHOTOS_BUCKET).getPublicUrl(path);
  return { url: data.publicUrl, path, error: null };
}

export async function removeStaffPhoto(photoUrl?: string | null) {
  if (!photoUrl) return { error: null };
  const marker = `/storage/v1/object/public/${STAFF_PHOTOS_BUCKET}/`;
  const index = photoUrl.indexOf(marker);
  if (index < 0) return { error: null };

  const path = decodeURIComponent(photoUrl.slice(index + marker.length));
  return supabase.storage.from(STAFF_PHOTOS_BUCKET).remove([path]);
}

export async function createShippingStaff(input: StaffUserInput) {
  const { data, error } = await supabase
    .from("staff_users")
    .insert({
      store_id: input.store_id,
      username: input.username.trim().toLowerCase(),
      password_hash: input.password,
      role: input.role,
      status: input.status,
      first_name: input.first_name.trim(),
      last_name: input.last_name.trim(),
      phone: normalize(input.phone),
      whatsapp: normalize(input.whatsapp),
      email: normalize(input.email)?.toLowerCase() || null,
      photo_url: normalize(input.photo_url),
      vehicle_type: normalize(input.vehicle_type),
      vehicle_plate: normalize(input.vehicle_plate)?.toUpperCase() || null,
      notes: normalize(input.notes),
    })
    .select("*")
    .single();

  return { data: data as StaffUser | null, error };
}

export async function updateShippingStaff(
  id: string,
  input: Omit<StaffUserInput, "store_id" | "password"> & { password?: string }
) {
  const payload: Record<string, unknown> = {
    username: input.username.trim().toLowerCase(),
    role: input.role,
    status: input.status,
    first_name: input.first_name.trim(),
    last_name: input.last_name.trim(),
    phone: normalize(input.phone),
    whatsapp: normalize(input.whatsapp),
    email: normalize(input.email)?.toLowerCase() || null,
    photo_url: normalize(input.photo_url),
    vehicle_type: normalize(input.vehicle_type),
    vehicle_plate: normalize(input.vehicle_plate)?.toUpperCase() || null,
    notes: normalize(input.notes),
    updated_at: new Date().toISOString(),
  };

  if (input.password?.trim()) payload.password_hash = input.password.trim();

  const { data, error } = await supabase
    .from("staff_users")
    .update(payload)
    .eq("id", id)
    .select("*")
    .single();

  return { data: data as StaffUser | null, error };
}

export async function setShippingStaffStatus(id: string, status: StaffUser["status"]) {
  const { error } = await supabase
    .from("staff_users")
    .update({ status, updated_at: new Date().toISOString() })
    .eq("id", id);

  return { error };
}

export async function getStaffShipments(storeId: string, staff: StaffUser) {
  let query = supabase
    .from("shipments")
    .select("id,order_number,trip_order,tracking_code,recipient_name,recipient_address,recipient_phone,location,status,delivered,delivered_date,created_at,assigned_driver_id,assigned_driver_name")
    .eq("store_id", storeId)
    .is("deleted_at", null)
    .order("delivered", { ascending: true })
    .order("trip_order", { ascending: true, nullsFirst: false })
    .order("order_number", { ascending: true, nullsFirst: false });

  // Los nuevos envíos deben usar assigned_driver_id. El nombre se conserva
  // como respaldo temporal para los envíos creados antes de este módulo.
  query = query.or(`assigned_driver_id.eq.${staff.id},assigned_driver_name.eq.${staff.first_name} ${staff.last_name}`);

  const { data, error } = await query;
  return { data: (data || []) as StaffShipment[], error };
}
