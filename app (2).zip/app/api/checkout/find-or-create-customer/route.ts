// Guardar en: app/api/checkout/find-or-create-customer/route.ts
//
// Reemplaza la función `createOrUpdateCustomer` del checkout, que
// hoy hace `.select("*").eq("email", ...)` y `.insert()` directo
// desde el navegador con la key anónima. Igual que con orders,
// esto permite cerrar customers.SELECT / customers.INSERT en RLS
// sin romper el checkout — el navegador ya no toca la tabla
// customers directamente.

import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase-admin";

const clean = (value: unknown, max = 200) => String(value ?? "").trim().slice(0, max);
const fail = (message: string, status = 400) =>
  NextResponse.json({ success: false, message }, { status });

export async function POST(request: Request) {
  let body: {
    storeId?: string;
    name?: string;
    email?: string;
    phone?: string;
    city?: string;
  };

  try {
    body = await request.json();
  } catch {
    return fail("Cuerpo de la solicitud inválido.");
  }

  const storeId = clean(body.storeId, 64);
  const email = clean(body.email, 200).toLowerCase();
  const name = clean(body.name, 150);
  const phone = clean(body.phone, 40);
  const city = clean(body.city, 120);

  if (!storeId || !email || !name || !phone) {
    return fail("Faltan datos obligatorios del cliente.");
  }

  const { data: store, error: storeError } = await supabaseAdmin
    .from("stores")
    .select("id, is_active")
    .eq("id", storeId)
    .maybeSingle();

  if (storeError) return fail("No se pudo validar la tienda.", 500);
  if (!store || store.is_active === false) {
    return fail("Esta tienda no está disponible.", 404);
  }

  const { data: existing, error: findError } = await supabaseAdmin
    .from("customers")
    .select("id")
    .eq("store_id", storeId)
    .eq("email", email)
    .maybeSingle();

  if (findError) return fail("No se pudo verificar el cliente.", 500);

  if (existing) {
    const { error: updateError } = await supabaseAdmin
      .from("customers")
      .update({ name, phone, city })
      .eq("id", existing.id)
      .eq("store_id", storeId);

    if (updateError) return fail("No se pudo actualizar el cliente.", 500);

    return NextResponse.json({ success: true, customerId: existing.id });
  }

  const { data: created, error: insertError } = await supabaseAdmin
    .from("customers")
    .insert({ store_id: storeId, name, email, phone, city })
    .select("id")
    .single();

  if (insertError) {
    console.error("CREATE CUSTOMER ERROR:", insertError);
    return fail("No se pudo crear el cliente.", 500);
  }

  return NextResponse.json({ success: true, customerId: created.id });
}
