import { NextRequest, NextResponse } from "next/server";
import sharp from "sharp";

import { supabaseAdmin } from "@/lib/supabase-admin";

export const runtime = "nodejs";
export const maxDuration = 60;

type ImageKind = "product" | "combo" | "banner" | "logo" | "generic";

type Candidate = {
  key: string;
  table: string;
  id: string;
  column: string;
  url: string;
  kind: ImageKind;
  storagePathColumn?: string;
};

const SOURCES: Array<{
  table: string;
  columns: Array<{
    column: string;
    kind: ImageKind;
  }>;
  storagePathColumn?: string;
}> = [
  {
    table: "product_images",
    columns: [{ column: "image_url", kind: "product" }],
    storagePathColumn: "storage_path",
  },
];

function jsonError(message: string, status = 400) {
  return NextResponse.json({ ok: false, error: message }, { status });
}

async function requireSuperAdmin(request: NextRequest) {
  const authorization = request.headers.get("authorization") || "";
  const token = authorization.startsWith("Bearer ")
    ? authorization.slice(7)
    : "";

  if (!token) return { error: "Sesión no encontrada." };

  const { data: userData, error: userError } =
    await supabaseAdmin.auth.getUser(token);

  if (userError || !userData.user) {
    return { error: "Sesión inválida o vencida." };
  }

  const { data: profile, error: profileError } = await supabaseAdmin
    .from("profiles")
    .select("role, active")
    .eq("id", userData.user.id)
    .maybeSingle();

  if (
    profileError ||
    !profile ||
    profile.active !== true ||
    profile.role !== "super_admin"
  ) {
    return { error: "Solo un Super Admin puede ejecutar esta migración." };
  }

  return { user: userData.user };
}

function parseSupabaseStorageUrl(rawUrl: string) {
  try {
    const url = new URL(rawUrl);
    const markers = [
      "/storage/v1/object/public/",
      "/storage/v1/object/sign/",
      "/storage/v1/render/image/public/",
      "/storage/v1/render/image/sign/",
    ];

    const marker = markers.find((value) => url.pathname.includes(value));
    if (!marker) return null;

    const after = decodeURIComponent(url.pathname.split(marker)[1] || "");
    const slash = after.indexOf("/");
    if (slash <= 0) return null;

    const bucket = after.slice(0, slash);
    const path = after.slice(slash + 1);

    if (!bucket || !path) return null;

    return { bucket, path };
  } catch {
    return null;
  }
}

function alreadyOptimized(url: string) {
  const parsed = parseSupabaseStorageUrl(url);
  if (!parsed) return false;

  return (
    parsed.path.includes("/optimized/") ||
    parsed.path.endsWith(".webp") ||
    parsed.path.endsWith(".avif")
  );
}

function imageSettings(kind: ImageKind) {
  switch (kind) {
    case "banner":
      return { width: 1920, height: 1080, quality: 82, fit: "inside" as const };
    case "combo":
      return { width: 1600, height: 1100, quality: 80, fit: "inside" as const };
    case "logo":
      return { width: 1000, height: 1000, quality: 86, fit: "inside" as const };
    case "product":
      return { width: 1600, height: 1600, quality: 80, fit: "inside" as const };
    default:
      return { width: 1600, height: 1600, quality: 80, fit: "inside" as const };
  }
}

async function validateImageBuffer(buffer: Buffer, expectedFormat = "webp") {
  const metadata = await sharp(buffer, { sequentialRead: true }).metadata();

  if (
    metadata.format !== expectedFormat ||
    !metadata.width ||
    !metadata.height ||
    metadata.width < 2 ||
    metadata.height < 2
  ) {
    throw new Error(
      `La imagen generada no pasó la validación (${metadata.format || "sin formato"}).`
    );
  }

  // Fuerza una decodificación completa de píxeles, no solo de cabeceras.
  await sharp(buffer, { sequentialRead: true })
    .resize({ width: 8, height: 8, fit: "inside" })
    .raw()
    .toBuffer();

  return metadata;
}

async function scanCandidates(limit: number) {
  const results: Candidate[] = [];
  const warnings: string[] = [];

  // Solo product_images. Se pagina para que una imagen corrupta o pequeña
  // no bloquee el acceso a las imágenes válidas que vienen después.
  const pageSize = 100;
  let from = 0;
  let finished = false;

  while (!finished && results.length < limit) {
    const to = from + pageSize - 1;

    const { data, error } = await supabaseAdmin
      .from("product_images")
      .select("id,image_url,storage_path")
      .order("id", { ascending: true })
      .range(from, to);

    if (error) {
      warnings.push(`product_images: ${error.message}`);
      break;
    }

    const rows = data ?? [];

    if (rows.length < pageSize) {
      finished = true;
    }

    for (const rawRow of rows) {
      if (results.length >= limit) break;

      const row = rawRow as unknown as Record<string, unknown>;
      const id = String(row.id ?? "");
      const url = String(row.image_url ?? "").trim();

      if (!id || !url || alreadyOptimized(url)) {
        continue;
      }

      const parsed = parseSupabaseStorageUrl(url);
      if (!parsed) {
        warnings.push(`${id}: URL de Storage inválida.`);
        continue;
      }

      try {
        const { data: file, error: downloadError } =
          await supabaseAdmin.storage
            .from(parsed.bucket)
            .download(parsed.path);

        if (downloadError || !file) {
          warnings.push(
            `${id}: no se pudo descargar (${downloadError?.message || "sin archivo"}).`
          );
          continue;
        }

        // Ignorar archivos menores de 1 MB.
        if (file.size < 1_000_000) {
          continue;
        }

        const originalBuffer = Buffer.from(await file.arrayBuffer());

        // Valida que el archivo original sea realmente una imagen decodificable.
        // Si está corrupto o el formato no es compatible, se omite y el escaneo continúa.
        const metadata = await sharp(originalBuffer, {
          sequentialRead: true,
          failOn: "warning",
          limitInputPixels: 100_000_000,
        }).metadata();

        if (!metadata.width || !metadata.height || !metadata.format) {
          warnings.push(`${id}: imagen original inválida; fue omitida.`);
          continue;
        }

        // Fuerza una decodificación real para detectar cabeceras corruptas.
        await sharp(originalBuffer, {
          sequentialRead: true,
          failOn: "warning",
          limitInputPixels: 100_000_000,
        })
          .resize({ width: 8, height: 8, fit: "inside" })
          .raw()
          .toBuffer();

        results.push({
          key: `product_images:${id}:image_url`,
          table: "product_images",
          id,
          column: "image_url",
          url,
          kind: "product",
          storagePathColumn: "storage_path",
        });
      } catch (error) {
        warnings.push(
          `${id}: imagen corrupta o formato no compatible; se omitió. ${
            error instanceof Error ? error.message : ""
          }`.trim()
        );
      }
    }

    from += pageSize;

    // Límite de seguridad para evitar recorrer indefinidamente.
    if (from >= 10_000) {
      finished = true;
      warnings.push("El escaneo alcanzó el límite de seguridad de 10 000 filas.");
    }
  }

  return { candidates: results, warnings };
}

async function optimizeCandidate(
  candidate: Candidate,
  deleteOriginal: boolean
) {
  const parsed = parseSupabaseStorageUrl(candidate.url);

  if (!parsed) {
    return {
      skipped: true,
      message: "URL inválida. Imagen omitida.",
      oldUrl: candidate.url,
      newUrl: candidate.url,
      originalBytes: 0,
      optimizedBytes: 0,
      savedBytes: 0,
      originalDeleted: false,
    };
  }

  const { data: downloadData, error: downloadError } =
    await supabaseAdmin.storage.from(parsed.bucket).download(parsed.path);

  if (downloadError || !downloadData) {
    return {
      skipped: true,
      message:
        downloadError?.message ||
        "No se pudo descargar la imagen. Fue omitida.",
      oldUrl: candidate.url,
      newUrl: candidate.url,
      originalBytes: 0,
      optimizedBytes: 0,
      savedBytes: 0,
      originalDeleted: false,
    };
  }

  const originalBuffer = Buffer.from(await downloadData.arrayBuffer());
  const settings = imageSettings(candidate.kind);

  let optimizedBuffer: Buffer;

  try {
    // Todo el proceso de lectura y conversión queda dentro del mismo try.
    // Cualquier imagen dañada o formato no compatible se omite sin romper el lote.
    optimizedBuffer = await sharp(originalBuffer, {
      sequentialRead: true,
      failOn: "warning",
      limitInputPixels: 100_000_000,
    })
      .rotate()
      .toColorspace("srgb")
      .resize({
        width: settings.width,
        height: settings.height,
        fit: settings.fit,
        withoutEnlargement: true,
      })
      .webp({
        quality: settings.quality,
        effort: 4,
        smartSubsample: false,
      })
      .toBuffer();

    await validateImageBuffer(optimizedBuffer);
  } catch (error) {
    return {
      skipped: true,
      message: `Imagen corrupta o formato no compatible. Omitida. ${
        error instanceof Error ? error.message : ""
      }`.trim(),
      oldUrl: candidate.url,
      newUrl: candidate.url,
      originalBytes: originalBuffer.length,
      optimizedBytes: originalBuffer.length,
      savedBytes: 0,
      originalDeleted: false,
    };
  }

  const originalFolder = parsed.path.includes("/")
    ? parsed.path.slice(0, parsed.path.lastIndexOf("/"))
    : "";

  const optimizedPath = [
    originalFolder,
    "optimized",
    `${crypto.randomUUID()}.webp`,
  ]
    .filter(Boolean)
    .join("/");

  const exactArrayBuffer = optimizedBuffer.buffer.slice(
    optimizedBuffer.byteOffset,
    optimizedBuffer.byteOffset + optimizedBuffer.byteLength
  ) as ArrayBuffer;

  const { error: uploadError } = await supabaseAdmin.storage
    .from(parsed.bucket)
    .upload(optimizedPath, exactArrayBuffer, {
      contentType: "image/webp",
      cacheControl: "31536000",
      upsert: false,
    });

  if (uploadError) {
    return {
      skipped: true,
      message: `No se pudo subir la versión optimizada. Omitida. ${uploadError.message}`,
      oldUrl: candidate.url,
      newUrl: candidate.url,
      originalBytes: originalBuffer.length,
      optimizedBytes: originalBuffer.length,
      savedBytes: 0,
      originalDeleted: false,
    };
  }

  try {
    const { data: uploadedData, error: uploadedDownloadError } =
      await supabaseAdmin.storage
        .from(parsed.bucket)
        .download(optimizedPath);

    if (uploadedDownloadError || !uploadedData) {
      throw new Error(
        uploadedDownloadError?.message ||
          "No se pudo verificar el archivo después de subirlo."
      );
    }

    const uploadedBuffer = Buffer.from(await uploadedData.arrayBuffer());
    await validateImageBuffer(uploadedBuffer);
  } catch (error) {
    await supabaseAdmin.storage.from(parsed.bucket).remove([optimizedPath]);

    return {
      skipped: true,
      message: `La versión subida no pasó la validación y fue eliminada. ${
        error instanceof Error ? error.message : ""
      }`.trim(),
      oldUrl: candidate.url,
      newUrl: candidate.url,
      originalBytes: originalBuffer.length,
      optimizedBytes: originalBuffer.length,
      savedBytes: 0,
      originalDeleted: false,
    };
  }

  const { data: publicUrlData } = supabaseAdmin.storage
    .from(parsed.bucket)
    .getPublicUrl(optimizedPath);

  const updatePayload: Record<string, string> = {
    [candidate.column]: publicUrlData.publicUrl,
  };

  if (candidate.storagePathColumn) {
    updatePayload[candidate.storagePathColumn] = optimizedPath;
  }

  const { error: updateError } = await supabaseAdmin
    .from(candidate.table)
    .update(updatePayload)
    .eq("id", candidate.id);

  if (updateError) {
    await supabaseAdmin.storage.from(parsed.bucket).remove([optimizedPath]);

    return {
      skipped: true,
      message: `No se actualizó la base de datos. Omitida. ${updateError.message}`,
      oldUrl: candidate.url,
      newUrl: candidate.url,
      originalBytes: originalBuffer.length,
      optimizedBytes: originalBuffer.length,
      savedBytes: 0,
      originalDeleted: false,
    };
  }

  let originalDeleted = false;

  if (deleteOriginal && parsed.path !== optimizedPath) {
    const { error: deleteError } = await supabaseAdmin.storage
      .from(parsed.bucket)
      .remove([parsed.path]);

    if (!deleteError) originalDeleted = true;
  }

  return {
    skipped: false,
    oldUrl: candidate.url,
    newUrl: publicUrlData.publicUrl,
    originalBytes: originalBuffer.length,
    optimizedBytes: optimizedBuffer.length,
    savedBytes: Math.max(originalBuffer.length - optimizedBuffer.length, 0),
    originalDeleted,
  };
}

export async function POST(request: NextRequest) {
  const access = await requireSuperAdmin(request);

  if ("error" in access) {
    return jsonError(
      access.error ?? "No tienes permisos para ejecutar esta migración.",
      403
    );
  }

  let body: {
    action?: "scan" | "optimize";
    limit?: number;
    candidate?: Candidate;
    deleteOriginal?: boolean;
  };

  try {
    body = await request.json();
  } catch {
    return jsonError("Solicitud inválida.");
  }

  if (body.action === "scan") {
    const limit = Math.min(Math.max(Number(body.limit || 250), 1), 1000);
    const result = await scanCandidates(limit);

    return NextResponse.json({
      ok: true,
      ...result,
    });
  }

  if (body.action === "optimize") {
    if (!body.candidate) {
      return jsonError("Falta la imagen que se va a optimizar.");
    }

    try {
      const result = await optimizeCandidate(
        body.candidate,
        body.deleteOriginal === true
      );

if ((result as any).skipped) {
  return NextResponse.json({
    ok: true,
    skipped: true,
    result,
  });
}

return NextResponse.json({
  ok: true,
  result,
});
    } catch (error) {
      return jsonError(
        error instanceof Error ? error.message : "No se pudo optimizar."
      );
    }
  }

  return jsonError("Acción no reconocida.");
}